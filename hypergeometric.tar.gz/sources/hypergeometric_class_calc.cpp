#include <my_includes.h>
#include <HypCalculator.h>
using namespace std;

complex<double> hyperg_func_series(const double x);
complex<double> hyperg_func_eta(const double x);
complex<double> hyperg_func_1mZ(const double x); 
const int eta_points = 4;
const double eta[eta_points] = {0.005, 0.01, 0.1, 0.2};
double epsilon = 1e-12;
double xmin[3] = {0.0, 0.5, 1.5};
double xmax[3] = {0.7, 1.7, 3.0};
const int npoints = 1000;

HypCalculator* my_HypCalculator;

int main() 
{
  my_HypCalculator = new HypCalculator();

  double x[npoints];
  double F_real[eta_points][npoints];
  double F_imag[eta_points][npoints];

  TFile* outputfile = new TFile("hyperg_class_graphs.root", "recreate");
  TGraph* g1_real[eta_points];
  TGraph* g1_imag[eta_points];
  TGraph* g2_real[eta_points];
  TGraph* g2_imag[eta_points];
  TGraph* g3_real[eta_points];
  TGraph* g3_imag[eta_points];
  outputfile->cd();
   
  for(int ix = 0; ix < 3; ix++)
  {

    for(int ipoint = 0; ipoint < npoints; ipoint++)
      x[ipoint] = xmin[ix] + (xmax[ix] - xmin[ix]) * 1.0 / npoints * (ipoint + 0.5);

    if(ix == 0)
    {
      for(int eta_ipoint = 0; eta_ipoint < eta_points; eta_ipoint++)
      { 
        g1_real[eta_ipoint] = new TGraph();
        g1_imag[eta_ipoint] = new TGraph();
//    cout << "ieta = " << eta_ipoint << endl;
        complex<double> a(0., eta[eta_ipoint]);
        complex<double> b(1., eta[eta_ipoint]);
        complex<double> c(1., 0.);
        my_HypCalculator->initialize_abc(a, b, c);
        for(int ipoint = 0; ipoint < npoints; ipoint++)
        {
          complex<double> val = hyperg_func_series(x[ipoint]);
          g1_real[eta_ipoint]->AddPoint(x[ipoint], real(val)); 
          g1_imag[eta_ipoint]->AddPoint(x[ipoint], imag(val)); 
        }
        g1_real[eta_ipoint]->SetName(Form("gr1_real%d", eta_ipoint+1));
        g1_imag[eta_ipoint]->SetName(Form("gr1_imag%d", eta_ipoint+1));
        g1_real[eta_ipoint]->Write();
        g1_imag[eta_ipoint]->Write();
      }

    }

    if(ix == 1)
    {
      for(int eta_ipoint = 0; eta_ipoint < eta_points; eta_ipoint++)
      { 
        g2_real[eta_ipoint] = new TGraph();
        g2_imag[eta_ipoint] = new TGraph();
//    cout << "ieta = " << eta_ipoint << endl;
        complex<double> a(0., eta[eta_ipoint]);
        complex<double> b(1., eta[eta_ipoint]);
        complex<double> c(1., 0.);
        my_HypCalculator->initialize_abc(a, b, c);
        for(int ipoint = 0; ipoint < npoints; ipoint++)
        {
          complex<double> val = hyperg_func_1mZ(x[ipoint]);
          g2_real[eta_ipoint]->AddPoint(x[ipoint], real(val)); 
          g2_imag[eta_ipoint]->AddPoint(x[ipoint], imag(val)); 
        }
        g2_real[eta_ipoint]->SetName(Form("gr2_real%d", eta_ipoint+1));
        g2_imag[eta_ipoint]->SetName(Form("gr2_imag%d", eta_ipoint+1));
        g2_real[eta_ipoint]->Write();
        g2_imag[eta_ipoint]->Write();
      }

    }

    if(ix == 2)
    {
      for(int eta_ipoint = 0; eta_ipoint < eta_points; eta_ipoint++)
      { 
        cout << " ieta = " << eta_ipoint << ", eta = " << eta[eta_ipoint] << endl;
        g3_real[eta_ipoint] = new TGraph();
        g3_imag[eta_ipoint] = new TGraph();
//    cout << "ieta = " << eta_ipoint << endl;
        my_HypCalculator->initialize_eta(eta[eta_ipoint]);
        for(int ipoint = 0; ipoint < npoints; ipoint++)
        {
          complex<double> val = hyperg_func_eta(x[ipoint]);
          g3_real[eta_ipoint]->AddPoint(x[ipoint], real(val)); 
          g3_imag[eta_ipoint]->AddPoint(x[ipoint], imag(val)); 
        }
        g3_real[eta_ipoint]->SetName(Form("gr3_real%d", eta_ipoint+1));
        g3_imag[eta_ipoint]->SetName(Form("gr3_imag%d", eta_ipoint+1));
        g3_real[eta_ipoint]->Write();
        g3_imag[eta_ipoint]->Write();
      }

    }
  }
  
  outputfile->Close();
  for (int ieta = 0; ieta < eta_points; ieta++)
  {
    delete g1_real[ieta];
    delete g1_imag[ieta];
    delete g2_real[ieta];
    delete g2_imag[ieta];
    delete g3_real[ieta];
    delete g3_imag[ieta];
  }
  delete outputfile;
  delete my_HypCalculator;
  return 0;
}

complex<double> hyperg_func_series(const double x) 
{
//  complex<double> z(x, 0.);
  return my_HypCalculator->Gauss_2F1_series0(x);
}

complex<double> hyperg_func_1mZ(const double x) 
{
//  complex<double> z(x, 0.);
  return my_HypCalculator->Gauss_2F1_1mZ_noint(x);
}

complex<double> hyperg_func_eta(const double x) 
{
  complex<double> val = my_HypCalculator->Gauss_2F1_c_1(x);
  return val;
}
