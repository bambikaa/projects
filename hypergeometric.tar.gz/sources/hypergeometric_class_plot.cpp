#include <my_includes.h>
using namespace std;

const char* infilename = "/home/aletta/work/hyperg_class_graphs.root";
const char* figname = "hyperg_class_real.png";
const char* figname2 = "hyperg_class_imag.png";
const int eta_points = 4;
double eta [eta_points] = {0, 0.01, 0.1, 0.2,};
const int my_colors1[eta_points] = {416, 632, 880, 800};
const int my_colors2[eta_points] = {418, 634, 882, 802};
const int my_colors3[eta_points] = {420, 636, 884, 804};
const double xmin[3] = {0.0, 0.5, 1.5};
const double xmax[3] = {0.7, 1.7, 3.0};
int main() 
{
  TCanvas* c1 = new TCanvas("c1", "Canvas", 10, 10, 700, 500);
  TGraph* g_real1[eta_points]; 
  TGraph* g_real2[eta_points]; 
  TGraph* g_real3[eta_points]; 
  TMultiGraph *mg_real = new TMultiGraph();
  TLine* line1 = new TLine();
  TLine* line2 = new TLine();
  line1->SetNDC(kTRUE);
  line2->SetNDC(kTRUE);
  line1->
  TFile* infile = new TFile(infilename, "read");
//  c1->SetLogy(1);
  TLegend* leg = new TLegend(0.25, 0.35, 0.1, 0.1);
  for(int ieta = 0; ieta < eta_points; ieta++)
  {
    g_real1[ieta] = (TGraph*)infile->Get(Form("gr1_real%d", ieta +1));
    g_real2[ieta] = (TGraph*)infile->Get(Form("gr2_real%d", ieta +1));
    g_real3[ieta] = (TGraph*)infile->Get(Form("gr3_real%d", ieta +1));
    g_real1[ieta]->SetLineColor(my_colors1[ieta]);
    g_real2[ieta]->SetLineColor(my_colors2[ieta]);
    g_real3[ieta]->SetLineColor(my_colors3[ieta]);
    g_real1[ieta]->SetMarkerColor(my_colors1[ieta]);
    g_real2[ieta]->SetMarkerColor(my_colors2[ieta]);
    g_real3[ieta]->SetMarkerColor(my_colors3[ieta]);
    g_real1[ieta]->SetLineWidth(2.5);
    g_real2[ieta]->SetLineWidth(2.5);
    g_real3[ieta]->SetLineWidth(2.5);
//    g[ieta]->GetYaxis()->SetRangeUser(0.0001, 1.);
    leg->AddEntry(g_real1[ieta], Form("#eta = %g", eta[ieta]) , "l");
    mg_real->Add(g_real1[ieta]);
    mg_real->Add(g_real2[ieta]);
    mg_real->Add(g_real3[ieta]);
  }
//  mg_real->GetYaxis()->SetRangeUser(-2.,2.);
  mg_real->SetTitle("Real part of hypergeometric function; x; F");
  mg_real->Draw("a");
  leg->Draw();
  c1->Print(figname);
  c1->Clear();

//  TCanvas* c1 = new TCanvas("c1", "Canvas", 10, 10, 700, 500);
  TGraph* g_imag1[eta_points]; 
  TGraph* g_imag2[eta_points]; 
  TGraph* g_imag3[eta_points]; 
  TMultiGraph *mg_imag = new TMultiGraph();
  TLegend* leg2 = new TLegend(0.9, 0.35, 0.75, 0.1);
//  c1->SetLogy(1);
  for(int ieta = 0; ieta < eta_points; ieta++)
  {
    g_imag1[ieta] = (TGraph*)infile->Get(Form("gr1_imag%d", ieta +1));
    g_imag2[ieta] = (TGraph*)infile->Get(Form("gr2_imag%d", ieta +1));
    g_imag3[ieta] = (TGraph*)infile->Get(Form("gr3_imag%d", ieta +1));
    g_imag1[ieta]->SetLineColor(my_colors1[ieta]);
    g_imag2[ieta]->SetLineColor(my_colors2[ieta]);
    g_imag3[ieta]->SetLineColor(my_colors3[ieta]);
    g_imag1[ieta]->SetMarkerColor(my_colors1[ieta]);
    g_imag2[ieta]->SetMarkerColor(my_colors2[ieta]);
    g_imag3[ieta]->SetMarkerColor(my_colors3[ieta]);
    g_imag1[ieta]->SetLineWidth(2.5);
    g_imag2[ieta]->SetLineWidth(2.5);
    g_imag3[ieta]->SetLineWidth(2.5);
//    g[ieta]->GetYaxis()->SetRangeUser(0.0001, 1.);
    leg2->AddEntry(g_imag1[ieta], Form("#eta = %g", eta[ieta]) , "l");
    mg_imag->Add(g_imag1[ieta]);
    mg_imag->Add(g_imag2[ieta]);
    mg_imag->Add(g_imag3[ieta]);
  }
  mg_imag->SetTitle("Imaginary part of hypergeometric function; x; F");
//  mg_imag->GetYaxis()->SetRangeUser(-2.,2.);
  mg_imag->Draw("a");
  leg2->Draw();
  c1->Print(figname2);
  c1->Clear();

  delete mg_imag;
  delete mg_real;
  delete infile;
  delete c1;
  delete leg;
  delete leg2;
  return 0;
}
